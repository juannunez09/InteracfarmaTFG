const express = require('express'),
      path = require('path'),
      bodyParser = require('body-parser'),
      cors = require('cors');
      mongoose = require('mongoose'),
      config = require('./database');

// startings
const app = express();


// Middlewares
app.use(express.urlencoded({extended: true}));
app.use(bodyParser.json());

// Settings
app.set('port', process.env.PORT || 4000);

// Routes
app.get('/',(req, res) =>{
  res.send('connect');
});

/* Routes library */
const apiRoutes = require('./src/app/dbservices/farmacos.route');
  mongoose.Promise = global.Promise;
  app.use(cors());
  app.use('/api', apiRoutes);

module.exports = app;
