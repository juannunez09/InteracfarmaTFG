import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './componentes/home/home.component';
import { IngresarComponent } from './componentes/ingresar/ingresar.component';
import { FarmacolistComponent } from './componentes/farmacolist/farmacolist.component';


const routes: Routes = [
  // {
  // path: '', redirectTo: 'listado', pathMatch:'full'
  // },
  {
  path: '',component : HomeComponent
},{
  path: 'ingresar', component :IngresarComponent
},{
  path: 'listado', component:FarmacolistComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
