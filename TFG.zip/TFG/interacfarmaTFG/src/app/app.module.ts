import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './componentes/home/home.component';
import { FarmacolistComponent } from './componentes/farmacolist/farmacolist.component';
import { IngresarComponent } from './componentes/ingresar/ingresar.component';
import { PharmacoserviceService } from './servicios/pharmacoservice.service';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {NgbPaginationModule, NgbAlertModule} from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDialogModule} from '@angular/material/dialog';
import { AlertModalComponent } from './componentes/alert-modal/alert-modal.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FarmacolistComponent,
    IngresarComponent,
    AlertModalComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    NgbModule,
    NgbPaginationModule,
    NgbAlertModule,
    BrowserAnimationsModule,
    MatDialogModule
  ],
  providers: [PharmacoserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
