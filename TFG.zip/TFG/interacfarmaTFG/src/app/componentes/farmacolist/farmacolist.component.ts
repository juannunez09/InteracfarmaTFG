import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PharmacoserviceService } from '../../servicios/pharmacoservice.service';
import { Farmaco } from '../../models/farmaco/farmaco.model';
import { MatDialog } from '@angular/material/dialog';

import { AlertModalComponent } from '../alert-modal/alert-modal.component';

@Component({
  selector: 'app-farmacolist',
  templateUrl: './farmacolist.component.html',
  styleUrls: ['./farmacolist.component.css']
})
export class FarmacolistComponent implements OnInit {
  farmacoList: Farmaco;
  farmacoList2: Farmaco;

  filterFarmaco = '';
  filterFarmaco2 = '';

  constructor(private http: HttpClient,
              private FLS: PharmacoserviceService,
              private dialog: MatDialog) { }

  ngOnInit(): void {

  }

buscar(nombre: string, index: number){
  this.FLS.getFamaco(nombre).subscribe((data: Farmaco) => {
    if (index === 1){
      this.farmacoList = data;
    }else{
      this.farmacoList2 = data;
    }

    });
}
comparar(){
    if (this.farmacoList && this.farmacoList2){
      const arrayInteraccciones = this.farmacoList.interacciones.toLowerCase().split(', ');
      const fnombre2 = this.farmacoList2.nombre.toLowerCase();
      const found = arrayInteraccciones.filter( element => {
       return element.toLowerCase() === fnombre2;
      });

      const dialogRef = this.dialog.open(AlertModalComponent, {
        data: {
          datos: found
        }
      });
    }
  }
}
