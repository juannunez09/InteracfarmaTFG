import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormControl, FormGroup, FormGroupName, FormsModule } from '@angular/forms';
import { PharmacoserviceService } from '../../servicios/pharmacoservice.service';
import { Farmaco } from '../../models/farmaco/farmaco.model';

@Component({
  selector: 'app-ingresar',
  templateUrl: './ingresar.component.html',
  styleUrls: ['./ingresar.component.css']
})
export class IngresarComponent implements OnInit {

  formIngresarFarmaco:FormGroup;
  submitted = false;
  farmacoModel : Farmaco;

  constructor(private formBuilder : FormBuilder, private ps: PharmacoserviceService) {

    this.createForm();

  }

    createForm(){
      this.formIngresarFarmaco = this.formBuilder.group({
        nombre : [''],
        contraindicaciones:[''],
        interacciones:[''],
        embarazo:['']
      });
    }


  ngOnInit(): void {
  }

  get f() {

     return this.formIngresarFarmaco.controls;

    }

  onSubmit(){

    this.submitted = true;
    alert('SUCCESS!! \n\n' + JSON.stringify(this.formIngresarFarmaco.value, null, 4));
    this.farmacoModel = new Farmaco(this.f.nombre.value ,this.f.contraindicaciones.value,this.f.interacciones.value,this.f.embarazo.value);
    this.ps.addMedicaments(this.farmacoModel);

  }

  onReset() {
    this.submitted = false;
    this.formIngresarFarmaco.reset();
}


}
