const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Farmaco = new Schema({
  nombre:{
    type: String
  },
  contraindicaciones: {
    type: String
  },
  interacciones: {
    type: String
  },
  embarazo: {
    type: String
  }
},{
    collection: 'farmacos'
  });

module.exports = mongoose.model('Farmaco', Farmaco);
