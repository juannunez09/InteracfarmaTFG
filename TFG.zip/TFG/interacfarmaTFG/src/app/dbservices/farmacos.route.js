/* Libraries and initializing*/
const express = require('express');
const app = express();
const apiRoutes = express.Router();

/* CORS */
var cors = require('cors');
app.options('*', cors());

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

var corsOptions = {
  origin: 'http://localhost:4200',
  optionsSuccessStatus: 200
}

/* DB MODEL */
let FarmacoModel  = require('../dbmodels/Farmaco');

/* API PETITIONS */
apiRoutes.route('/addMedicine').post(function (req, res){

  let farmacoModel  = new FarmacoModel(req.body);
  this.farmacoModel = simpleStringify(this.farmacoModel);
  farmacoModel.save()
    .then( farmacoModel => {
    res.status(200).json({'FarmacoModel' : 'Farmaco introducido correctamente'});
  }).catch(err => {
    res.status(400).send('Error al introducirlo en la DB');
  });
});


function simpleStringify (object){
  var simpleObject = {};
  for (var prop in object ){
      if (!object.hasOwnProperty(prop)){
          continue;
      }
      if (typeof(object[prop]) == 'object'){
          continue;
      }
      if (typeof(object[prop]) == 'function'){
          continue;
      }
      simpleObject[prop] = object[prop];
  }
  return JSON.stringify(simpleObject); // returns cleaned up JSON
};


// Get all medicines from db
apiRoutes.route('/getAllMedicines').get(function (req, res){
  FarmacoModel.find(function(err, data) {
    if(err)
      console.log("Error al recoger la petición");
    else{
      res.json(data);
    }
  })
});


// get medicine

apiRoutes.route('/getOneMedicine/:nombre').get(function (req, res){
  const param = req.params.nombre;
  const query = { 'nombre' :  { $regex: new RegExp(`^${param}$`), $options: 'i' } };

  FarmacoModel.findOne(query)
    .then(data => {
      res.json(data);
    })
  .catch (error => {
     res.send(error.message);
  });
});



module.exports = apiRoutes;
