
export class Farmaco{

  nombre : string;
  contraindicaciones : string;
  interacciones : string;
  embarazo : string;

  constructor(nombre : string, contraindicaciones : string,interacciones : string,embarazo : string){
    this.nombre = nombre;
    this.contraindicaciones = contraindicaciones;
    this.interacciones = interacciones;
    this.embarazo = embarazo;

  }

}


