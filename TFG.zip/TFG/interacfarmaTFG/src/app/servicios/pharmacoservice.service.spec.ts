import { TestBed } from '@angular/core/testing';

import { PharmacoserviceService } from './pharmacoservice.service';

describe('PharmacoserviceService', () => {
  let service: PharmacoserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PharmacoserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
