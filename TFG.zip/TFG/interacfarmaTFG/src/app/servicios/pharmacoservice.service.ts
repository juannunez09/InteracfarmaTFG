import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Farmaco } from '../models/farmaco/farmaco.model';

@Injectable({
  providedIn: 'root'
})
export class PharmacoserviceService {


  uri = 'http://localhost:4000/api';

  constructor(private http: HttpClient) { }

  addMedicaments(farmaco : Farmaco){

    this.http.post(`${this.uri}/addMedicine`,farmaco).subscribe(res => console.log('Realizado con éxito'))
  }

  getFamaco(farmaco:string){

    return this.http.get(`${this.uri}/getOneMedicine/${farmaco}`);

  }

}
